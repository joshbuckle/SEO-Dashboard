<?php

$apikey = "#";
$Ganalytics = "#";
$url = "http://www.example.com";

?>